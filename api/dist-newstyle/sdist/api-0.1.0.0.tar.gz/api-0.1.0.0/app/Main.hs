module Main where

import Lib
import Server

main :: IO ()
main = start
