# Servant APIs
## Document
 * [InvestPlan](docs/investPlan.md) : `POST /saving` 
 * [RetirePlan](docs/retirePlan.md) : `POST /retire`